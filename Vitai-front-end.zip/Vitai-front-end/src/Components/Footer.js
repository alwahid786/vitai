import React from "react";

const Footer = () => {
  return (
    <>
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-12">
          {/*<div className="cus-footer"></div>*/}
        </div>
      </div>
    </div>
    </>
  );
};

export default Footer;
